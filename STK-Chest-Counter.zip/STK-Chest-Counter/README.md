# STK Chest Counter

Contador manual de baús para Android, com janela flutuante nativa (`WindowManager`), persistência local e painel arrastável/redimensionável.

## Requisitos
- Android 8.0 (API 26) ou superior; configurado para compilar com Android 15 / API 35.
- Java 17, Gradle 8.9, Android Gradle Plugin 8.7.3.

## Compilar pelo GitHub
1. Crie um repositório GitHub e envie todos os arquivos desta pasta para a branch `main` (ou `master`).
2. Abra a aba **Actions** e selecione **Build STK Chest Counter APK**. Também compila automaticamente em push e pull request.
3. Abra a execução concluída e baixe o artifact **app-debug.apk** na seção Artifacts.
4. Extraia o APK e instale no Android. Se solicitado, permita instalação do app usado para abrir o APK.

O workflow instala Java 17, Android SDK 35 e Gradle 8.9; não é necessário Android Studio.

## Primeiro uso
1. Abra STK Chest Counter.
2. Toque em **Conceder permissão de sobreposição** e habilite a permissão para o app nas configurações do Android.
3. Volte ao app e toque em **Ativar janela flutuante**.
4. Arraste o cabeçalho do painel para posicioná-lo. Use `A−` / `A+` para ajustar o tamanho.
5. Toque em `−` ou `+1` para alterar uma unidade. Segure por mais de 2 segundos para iniciar a repetição; solte para parar.
6. Para encerrar, use **Fechar janela flutuante** no app.

## Observações importantes
- A janela usa `TYPE_APPLICATION_OVERLAY`; apenas a área retangular do painel recebe toques. A área restante da tela continua disponível ao jogo. O Android não oferece passthrough seletivo confiável dentro da própria janela: os controles visíveis do painel consomem os toques que recebem.
- O serviço é iniciado por ação explícita do usuário e mantém uma notificação persistente. O Android, fabricantes e modos de economia de bateria ainda podem interromper processos; em aparelhos Xiaomi/POCO, talvez seja necessário permitir execução em segundo plano/início automático nas configurações do sistema.
- Android 13+ pode solicitar permissão de notificações. A permissão de sobreposição é separada e obrigatória.
- O projeto salva contador, posição e escala localmente em SharedPreferences; não precisa de internet.

## Estrutura
- `MainActivity.kt`: tela principal, permissões e comandos do serviço.
- `OverlayService.kt`: foreground service e janela `WindowManager`.
- `OverlayView.kt`: painel, arraste, botões e repetição por toque prolongado.
- `CounterManager.kt`: persistência local do contador e preferências do painel.
- `GradientFactory.kt`: tema azul e padrão original de ondas.
- `.github/workflows/android.yml`: build e publicação do APK como artifact.
