package com.stk.chestcounter

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var countLabel: TextView
    private lateinit var permissionLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        askNotificationPermissionIfNeeded()
    }

    override fun onResume() {
        super.onResume()
        if (::countLabel.isInitialized) refresh()
    }

    private fun buildScreen() {
        val root = WaveBackground(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(28), dp(24), dp(24))
        }
        val brand = TextView(this).apply {
            text = "STK  /  CHEST COUNTER"
            textSize = 22f; setTextColor(Color.rgb(14, 79, 130)); typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER; letterSpacing = .06f
        }
        root.addView(brand, LinearLayout.LayoutParams(-1, dp(64)))
        root.addView(TextView(this).apply {
            text = "CONTADOR MANUAL PARA SUAS PARTIDAS"
            textSize = 11f; letterSpacing = .12f; setTextColor(Color.rgb(67, 125, 164)); gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, dp(32)))
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(20), dp(22), dp(20), dp(22)); background = GradientFactory.card()
        }
        card.addView(TextView(this).apply { text = "BAÚS CONTABILIZADOS"; textSize = 12f; letterSpacing = .1f; setTextColor(0xFF467A9E.toInt()) })
        countLabel = TextView(this).apply { textSize = 56f; typeface = Typeface.create("sans-serif", Typeface.BOLD); setTextColor(0xFF145F9A.toInt()) }
        card.addView(countLabel)
        root.addView(card, LinearLayout.LayoutParams(-1, dp(170)).apply { topMargin = dp(26) })

        val permissionButton = makeButton("CONCEDER PERMISSÃO DE SOBREPOSIÇÃO") { openOverlaySettings() }
        root.addView(permissionButton, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(26) })
        permissionLabel = TextView(this).apply { textSize = 12f; gravity = Gravity.CENTER; setTextColor(0xFF416F8D.toInt()) }
        root.addView(permissionLabel, LinearLayout.LayoutParams(-1, dp(44)))
        root.addView(makeButton("ATIVAR JANELA FLUTUANTE") { startOverlay() }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(8) })
        root.addView(makeButton("FECHAR JANELA FLUTUANTE") { stopService(Intent(this, OverlayService::class.java)); Toast.makeText(this, "Sobreposição encerrada", Toast.LENGTH_SHORT).show() }, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(12) })
        root.addView(TextView(this).apply {
            text = "Na janela flutuante: arraste pelo topo, use − / + para ajustar o tamanho e segure os botões do contador para repetição."
            textSize = 13f; setTextColor(0xFF426F8C.toInt()); gravity = Gravity.CENTER; setPadding(dp(8), dp(24), dp(8), 0)
        }, LinearLayout.LayoutParams(-1, -2))
        root.addView(TextView(this).apply { text = "STK"; textSize = 14f; letterSpacing = .28f; typeface = Typeface.DEFAULT_BOLD; setTextColor(0xFF397BAA.toInt()); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refresh()
    }

    private fun refresh() {
        countLabel.text = CounterManager.get(this).toString()
        val granted = Settings.canDrawOverlays(this)
        permissionLabel.text = if (granted) "Permissão de sobreposição concedida ✓" else "Permissão necessária para aparecer sobre o jogo"
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) { openOverlaySettings(); return }
        val intent = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        Toast.makeText(this, "Janela flutuante ativada", Toast.LENGTH_SHORT).show()
    }

    private fun openOverlaySettings() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun askNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 41)
        }
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 14f; setTextColor(Color.WHITE)
        background = GradientFactory.button(); setOnClickListener { action() }
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
