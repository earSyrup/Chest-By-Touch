package com.stk.chestcounter

import android.content.Context

/** Small synchronous preference store: every counter change is persisted immediately. */
object CounterManager {
    private const val PREFS = "stk_counter"
    private const val KEY_COUNT = "count"
    private const val KEY_X = "overlay_x"
    private const val KEY_Y = "overlay_y"
    private const val KEY_SCALE = "overlay_scale"

    fun get(context: Context): Int = prefs(context).getInt(KEY_COUNT, 0).coerceAtLeast(0)
    fun set(context: Context, value: Int): Int {
        val safe = value.coerceAtLeast(0)
        prefs(context).edit().putInt(KEY_COUNT, safe).commit()
        return safe
    }
    fun change(context: Context, delta: Int): Int {
        val current = get(context)
        return set(context, (current + delta).coerceAtLeast(0))
    }
    fun position(context: Context): Pair<Int, Int> {
        val p = prefs(context)
        return p.getInt(KEY_X, 40) to p.getInt(KEY_Y, 180)
    }
    fun savePosition(context: Context, x: Int, y: Int) {
        prefs(context).edit().putInt(KEY_X, x).putInt(KEY_Y, y).apply()
    }
    fun scale(context: Context): Float = prefs(context).getFloat(KEY_SCALE, 1f).coerceIn(.65f, 1.3f)
    fun saveScale(context: Context, scale: Float) {
        prefs(context).edit().putFloat(KEY_SCALE, scale.coerceIn(.65f, 1.3f)).apply()
    }
    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
