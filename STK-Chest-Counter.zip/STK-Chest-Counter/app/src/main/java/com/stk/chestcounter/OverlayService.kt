package com.stk.chestcounter

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var panel: OverlayView? = null
    private lateinit var params: WindowManager.LayoutParams
    private val channelId = "stk_overlay_service"

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(7, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (panel == null) showPanel()
        return START_STICKY
    }

    private fun showPanel() {
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val pos = CounterManager.position(this)
        val density = resources.displayMetrics.density
        val scale = CounterManager.scale(this)
        params = WindowManager.LayoutParams(
            (218 * density).toInt(), (160 * density).toInt(),
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = pos.first; y = pos.second }
        val overlay = OverlayView(this, { dx, dy ->
            params.x += dx.toInt(); params.y += dy.toInt()
            try { panel?.let { windowManager.updateViewLayout(it, params) }; CounterManager.savePosition(this, params.x, params.y) } catch (_: Exception) { }
        }, { change ->
            val next = (CounterManager.scale(this) + change).coerceIn(.65f, 1.3f)
            CounterManager.saveScale(this, next)
            panel?.let { current ->
                current.scaleX = next
                current.scaleY = next
                try { windowManager.updateViewLayout(current, params) } catch (_: Exception) { }
            }
        })
        panel = overlay
        overlay.scaleX = scale; overlay.scaleY = scale
        windowManager.addView(overlay, params)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "STK Chest Counter", NotificationManager.IMPORTANCE_LOW).apply { description = "Mantém a janela flutuante ativa" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId) else Notification.Builder(this)
        return builder.setContentTitle("STK Chest Counter")
            .setContentText("Contador flutuante ativo — toque em Fechar no aplicativo para encerrar")
            .setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build()
    }
    override fun onDestroy() {
        panel?.cleanup()
        panel?.let { try { windowManager.removeView(it) } catch (_: Exception) { } }
        panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
