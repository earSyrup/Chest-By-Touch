package com.stk.chestcounter

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.LinearLayout
import android.widget.TextView

class OverlayView(context: Context, private val onMove: (Float, Float) -> Unit, private val onResize: (Float) -> Unit) : LinearLayout(context) {
    private val handler = Handler(Looper.getMainLooper())
    private val value = TextView(context)
    private var repeating = false
    private val delay = 2_000L
    private val repeatTask = object : Runnable {
        override fun run() {
            if (!repeating) return
            CounterManager.change(context, activeDelta)
            updateCount()
            handler.postDelayed(this, 85L)
        }
    }
    private var activeDelta = 0
    private var touchHeld = false
    private var longPressTriggered = false
    private val longPressTask = Runnable {
        if (touchHeld) {
            longPressTriggered = true
            repeating = true
            CounterManager.change(context, activeDelta)
            updateCount()
            handler.postDelayed(repeatTask, 85L)
        }
    }

    init {
        orientation = VERTICAL
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xEAF4FCFF.toInt(), 0xDDE1F4FF.toInt())).apply {
            cornerRadius = 24f; setStroke(2, 0xAFFFFFFF.toInt())
        }
        elevation = dp(10).toFloat(); setPadding(dp(9), dp(7), dp(9), dp(5))
        val header = TextView(context).apply {
            text = "STK  •  ARRASTE AQUI"; textSize = 10f; letterSpacing = .08f
            setTextColor(0xFF397AA7.toInt()); gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
            setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { dragRawX = event.rawX; dragRawY = event.rawY; true }
                    MotionEvent.ACTION_MOVE -> { val dx = event.rawX - dragRawX; val dy = event.rawY - dragRawY; dragRawX = event.rawX; dragRawY = event.rawY; onMove(dx, dy); true }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> true
                    else -> true
                }
            }
        }
        addView(header, LayoutParams(-1, dp(24)))
        value.apply { textSize = 28f; typeface = Typeface.create("sans-serif", Typeface.BOLD); setTextColor(0xFF145F9A.toInt()); gravity = Gravity.CENTER }
        addView(value, LayoutParams(-1, dp(42)))
        val controls = LinearLayout(context).apply { gravity = Gravity.CENTER; orientation = HORIZONTAL }
        controls.addView(counterButton("−", -1), LayoutParams(0, dp(42), 1f))
        controls.addView(counterButton("+1", 1), LayoutParams(0, dp(42), 1f).apply { leftMargin = dp(6) })
        addView(controls, LayoutParams(-1, dp(44)))
        val sizeRow = LinearLayout(context).apply { gravity = Gravity.CENTER; orientation = HORIZONTAL }
        sizeRow.addView(smallButton("A−") { onResize(-.08f) }, LayoutParams(0, dp(26), 1f))
        sizeRow.addView(smallButton("A+") { onResize(.08f) }, LayoutParams(0, dp(26), 1f).apply { leftMargin = dp(6) })
        addView(sizeRow, LayoutParams(-1, dp(29)))
        addView(TextView(context).apply { text = "STK"; textSize = 9f; letterSpacing = .25f; typeface = Typeface.DEFAULT_BOLD; setTextColor(0xFF397BAA.toInt()); gravity = Gravity.CENTER }, LayoutParams(-1, dp(15)))
        updateCount()
    }

    private var dragRawX = 0f
    private var dragRawY = 0f
    private fun counterButton(label: String, delta: Int): TextView = TextView(context).apply {
        text = label; textSize = if (label == "+1") 17f else 22f; typeface = Typeface.DEFAULT_BOLD
        setTextColor(Color.WHITE); gravity = Gravity.CENTER
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF1686D4.toInt(), 0xFF54B6E9.toInt())).apply { cornerRadius = dp(13).toFloat() }
        isClickable = true
        setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    activeDelta = delta
                    touchHeld = true
                    longPressTriggered = false
                    repeating = false
                    handler.removeCallbacks(repeatTask)
                    handler.removeCallbacks(longPressTask)
                    v.isPressed = true
                    handler.postDelayed(longPressTask, delay)
                    true
                }
                // Keep tracking the original touch target even if the finger moves
                // outside the button; Android sends UP/CANCEL to this listener.
                MotionEvent.ACTION_MOVE -> true
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val wasTap = event.actionMasked == MotionEvent.ACTION_UP && !longPressTriggered
                    touchHeld = false
                    handler.removeCallbacks(longPressTask)
                    if (wasTap) {
                        CounterManager.change(context, delta)
                        updateCount()
                    }
                    repeating = false
                    handler.removeCallbacks(repeatTask)
                    v.isPressed = false
                    true
                }
                else -> true
            }
        }
    }

    private fun smallButton(label: String, action: () -> Unit) = TextView(context).apply {
        text = label; textSize = 11f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setTextColor(0xFF246D9D.toInt())
        background = GradientDrawable().apply { setColor(0xAAFFFFFF.toInt()); cornerRadius = dp(9).toFloat() }
        setOnClickListener { action() }
    }
    fun updateCount() { value.text = CounterManager.get(context).toString() }
    fun cleanup() { touchHeld = false; repeating = false; handler.removeCallbacksAndMessages(null) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
