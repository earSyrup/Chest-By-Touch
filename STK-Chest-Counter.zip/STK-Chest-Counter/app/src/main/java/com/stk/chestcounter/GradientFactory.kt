package com.stk.chestcounter

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.drawable.GradientDrawable
import android.view.View

object GradientFactory {
    fun card() = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xEFFFFFFF.toInt(), 0xD9DDF3FF.toInt())).apply {
        cornerRadius = 30f; setStroke(1, 0xA6FFFFFF.toInt())
    }
    fun button() = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF1686D4.toInt(), 0xFF55B5E9.toInt())).apply { cornerRadius = 22f }
}

/** Subtle original wave motif; no game or anime artwork is used. */
class WaveBackground(context: Context) : android.widget.LinearLayout(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.2f; color = 0x243A9ACB }
    init { setWillNotDraw(false) }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(0xFFEAF7FF.toInt())
        val step = 42f * resources.displayMetrics.density
        var y = height * .62f
        while (y < height + step) {
            var x = -step
            while (x < width + step) {
                val p = Path().apply {
                    moveTo(x, y)
                    cubicTo(x + step * .22f, y - step * .42f, x + step * .48f, y - step * .42f, x + step * .7f, y)
                    cubicTo(x + step * .88f, y + step * .24f, x + step, y + step * .24f, x + step * 1.15f, y)
                }
                canvas.drawPath(p, paint); x += step * 1.15f
            }
            y += step * .58f
        }
    }
}
